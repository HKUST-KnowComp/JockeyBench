import copy
import hashlib
import json
import math
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src import acquisition, interface, scoring

class ProtocolTests(unittest.TestCase):
    def setUp(self):
        self.prediction = {"ranking": ["01", "02", "03"], "probabilities": {"01": 0.5, "02": 0.3, "03": 0.2}}
        self.fact = {"active": ["01", "02", "03"], "scratches": [], "winners": ["01"]}

    def message(self, prediction=None):
        return {"tool_calls": [{"function": {"name": "submit", "arguments": json.dumps(prediction or self.prediction)}}]}

    def test_fixed_prompt_hashes(self):
        source = json.loads((ROOT / "sources.json").read_text())
        for name, expected in source["fixed_prompt_sha256"].items():
            with self.subTest(name=name):
                self.assertEqual(hashlib.sha256((ROOT / "prompts" / name).read_bytes()).hexdigest(), expected)

    def test_repair_uses_existing_prompt(self):
        prompts = ROOT / "prompts"
        self.assertEqual((prompts / "repair-system.txt").read_bytes(),
                         (prompts / "system.txt").read_bytes() + (prompts / "repair.txt").read_bytes())

    def test_native_submit_schema(self):
        schema = interface.submit_schema(["01", "02", "03"])
        stored = json.loads((ROOT / "prompts/tools.json").read_text())
        self.assertEqual(stored["prediction"], [schema])
        self.assertEqual(stored["repair"], [schema])
        self.assertEqual(stored["updater"], interface.toolset())
        self.assertEqual(len(stored["warmup"]), 17)

    def test_submit_schema_tracks_field_size(self):
        for count in (2, 3, 16):
            numbers = [str(i + 1) for i in range(count)]
            parameters = interface.submit_schema(numbers)["function"]["parameters"]
            self.assertEqual(parameters["properties"]["ranking"]["maxItems"], count)
            self.assertEqual(parameters["properties"]["probabilities"]["required"], numbers)

    def test_forecast_only_offers_submit(self):
        numbers = list(self.prediction["ranking"])
        for repair in (False, True):
            request = interface.forecast_request({"mode": "prediction", "synthetic": True}, numbers, repair)
            self.assertEqual([t["function"]["name"] for t in request["tools"]], ["submit"])
            self.assertEqual(request["tool_choice"]["function"]["name"], "submit")
            self.assertFalse(request["parallel_tool_calls"])
            self.assertEqual([m["role"] for m in request["messages"]], ["system", "user"])

    def test_forecast_json_matches_runtime_serialization(self):
        observation = {"mode": "prediction", "synthetic": {"missing": None, "values": [1, 2]}}
        request = interface.forecast_request(observation, ["01", "02", "03"])
        expected = json.dumps(observation, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        self.assertEqual(request["messages"][1]["content"], expected)
        with self.assertRaises(ValueError):
            interface.forecast_request({"synthetic": math.nan}, ["01", "02", "03"])

    def test_initial_context_uses_bound_warmup_configuration(self):
        context = json.loads((ROOT / "prompts/initial_context.json").read_text())
        config = json.loads((ROOT / "config/reference.json").read_text())
        self.assertEqual(context["tariff"], config["warmup"]["effective_configuration"]["tariff"])
        self.assertEqual(context["limits"], config["warmup"]["effective_configuration"]["limits"])
        self.assertEqual(context["normal_requests"] + context["repair_reserve"], 40)
        self.assertEqual(context["tariff"]["hit_bonus_yen"], 100)
        self.assertEqual(config["formal_child_configuration"]["tariff"]["hit_bonus_yen"], 0)

    def test_native_submit_parser(self):
        self.assertEqual(interface.parse_submit(self.message(), ["01", "02", "03"]), self.prediction)

    def test_terminal_action_count(self):
        for count in (0, 2):
            message = self.message()
            message["tool_calls"] *= count
            with self.assertRaises(scoring.Rejected):
                interface.parse_submit(message, ["01", "02", "03"])

    def test_forecast_research_tools_are_rejected(self):
        message = {"tool_calls": [{"function": {"name": "get_recent_history", "arguments": "{}"}}]}
        with self.assertRaises(scoring.Rejected):
            interface.parse_submit(message, ["01", "02", "03"])

    def test_bad_predictions(self):
        for probabilities in ({"01": 0.5, "02": 0.5}, {"01": 0.7, "02": 0.7, "03": 0.2},
                              {"01": math.nan, "02": 0.3, "03": 0.2}):
            prediction = {**self.prediction, "probabilities": probabilities}
            with self.subTest(probabilities=probabilities), self.assertRaises(scoring.Rejected):
                scoring.validate(prediction, ["01", "02", "03"])

    def test_duplicate_ranking(self):
        prediction = {**self.prediction, "ranking": ["01", "01", "03"]}
        with self.assertRaises(scoring.Rejected):
            scoring.validate(prediction, ["01", "02", "03"])

    def test_synthetic_acquisition_example(self):
        source = (ROOT / "examples/collect_evidence.py").read_text()
        self.assertIn("collect_evidence", acquisition.parse_source(source))

    def test_acquisition_depths(self):
        template = 'def collect_evidence(sdk, context):\n    sdk.call("recent_history", horse_number="01", depth=DEPTH)\n    sdk.call("track_context")\n    return sdk.package()\n'
        for depth in (1, 3, 5):
            acquisition.parse_source(template.replace("DEPTH", str(depth)))
        with self.assertRaises(acquisition.PolicyInvalid):
            acquisition.parse_source(template.replace("DEPTH", "2"))

    def test_acquisition_rejects_prediction_and_io(self):
        for source in ('import os\ndef collect_evidence(sdk, context):\n    return sdk.package()',
                       'def collect_evidence(sdk, context):\n    return {"probabilities": {}}',
                       'def collect_evidence(sdk, context):\n    sdk.call("results")\n    return sdk.package()'):
            with self.subTest(source=source), self.assertRaises(acquisition.PolicyInvalid):
                acquisition.parse_source(source)

    def test_quality_state_preserves_unknown(self):
        state = acquisition.empty_domain()
        self.assertIsNone(state["missing_ratio"])
        self.assertIsNone(state["available_history_start_count"])
        self.assertIsNone(state["deeper_available"])

    def test_quality_projection_hides_values(self):
        card = {"race_id": "synthetic-race", "day_index": 1, "feature_asof": 0,
                "facts": {"surface": "synthetic-A", "distance": 1000}, "runners": [{"number": "01"}]}
        observation = {"starts": [{"day_index": 0, "race_facts": {"surface": "synthetic-A", "distance": 1000},
                                   "runner_facts": {"unshared_fact": 12345}, "values": {"finish": 1}}]}
        quality = acquisition.quality({"domain": "recent_history", "depth": 1}, observation, {"next_cursor": True}, card)
        self.assertEqual(quality["records_returned"], 1)
        self.assertEqual(set(quality), set(acquisition.empty_domain()))
        self.assertNotIn("12345", json.dumps(quality))
        self.assertNotIn("finish", quality)
        control = acquisition.context(card)
        self.assertEqual(set(control), {"race_id", "day_index", "feature_asof", "field_size", "runners"})

    def test_common_and_aligned_nonuniform(self):
        common = scoring.score(self.prediction, self.fact, raw_research_cost=10)
        aligned = scoring.score(self.prediction, self.fact, raw_research_cost=10, view="aligned")
        self.assertAlmostEqual(common["gross"], aligned["gross"])
        self.assertAlmostEqual(common["hit_contribution"], 100 * (1 - 1/3))
        self.assertAlmostEqual(common["net"], common["gross"] - 5)

    def test_uniform_view_difference(self):
        numbers = [str(i) for i in range(1, 17)]
        prediction = {"ranking": numbers, "probabilities": {n: 1/16 for n in numbers}}
        fact = {"active": numbers, "scratches": [], "winners": [numbers[0]]}
        for delivery in ("uniform_submit", "execution_fallback"):
            common = scoring.score(prediction, fact, delivery=delivery)
            aligned = scoring.score(prediction, fact, delivery=delivery, view="aligned")
            self.assertAlmostEqual(common["log_reward"], 0)
            self.assertEqual(common["hit_contribution"], 93.75)
            self.assertEqual(aligned["hit_contribution"], 0)

    def test_scratch_renormalization(self):
        fact = {"active": ["01", "02"], "scratches": ["03"], "winners": ["02"]}
        result = scoring.score(self.prediction, fact)
        self.assertAlmostEqual(result["log_reward"], 100 * math.log(2 * (0.98 * 0.3 / 0.8 + 0.02 / 2)))

    def test_zero_surviving_mass(self):
        prediction = {"ranking": ["01", "02", "03"], "probabilities": {"01": 1.0, "02": 0.0, "03": 0.0}}
        fact = {"active": ["02", "03"], "scratches": ["01"], "winners": ["02"]}
        self.assertAlmostEqual(scoring.score(prediction, fact)["log_reward"], 0)

    def test_dead_heat_log_score(self):
        fact = {**self.fact, "winners": ["01", "02"]}
        expected = 100 * math.log(3 * ((0.98 * 0.5 + 0.02/3) + (0.98 * 0.3 + 0.02/3)) / 2)
        self.assertAlmostEqual(scoring.score(self.prediction, fact)["log_reward"], expected)

    def test_uniform_delivery_label(self):
        with self.assertRaises(scoring.Rejected):
            scoring.score(self.prediction, self.fact, delivery="execution_fallback")
