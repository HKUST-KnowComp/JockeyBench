"""Verify portable checksums and run synthetic interface tests."""
import hashlib
from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode = True
root = Path(__file__).resolve().parent
records = {}
for line in (root / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
    digest, name = line.split("  ", 1)
    candidate = root / name
    assert candidate.is_file() and not candidate.is_symlink(), name
    assert candidate.resolve().is_relative_to(root), name
    assert hashlib.sha256(candidate.read_bytes()).hexdigest() == digest, name
    records[name] = digest
actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() and p.name != "SHA256SUMS"}
assert set(records) == actual, "File inventory mismatch"
suite = unittest.defaultTestLoader.discover(str(root / "tests"))
result = unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
