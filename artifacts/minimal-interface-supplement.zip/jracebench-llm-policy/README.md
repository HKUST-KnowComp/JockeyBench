# JockeyBench LLM-as-policy interface supplement

Reference prompts, tool schemas, configuration, source excerpts and synthetic
tests for the evidence-plan workflow formerly named Adaptive Acquisition.
The reference binding is the audited DeepSeek-V4-Flash R1 updater-fixed
deployment and its matched Frozen control, identified in `sources.json`.

## Files

| Path | Contents |
| --- | --- |
| `prompts/` | Exact system messages for warmup, updating, forecasting and repair, phase instructions and input templates |
| `prompts/tools.json` | Complete warmup and updater schemas and a three-entrant forecast schema |
| `config/` | Bound formal-child configuration, warmup limits and environment metadata |
| `src/interface.py` | Native schema construction and terminal-action parsing |
| `src/acquisition.py` | Static acquisition-code validation and quality-only state projection |
| `src/scoring.py` | v0.6.0 validation primitives and adapters for common and aligned score views |
| `reference/` | Source excerpts for sessions, delivery, context fitting and score attribution |
| `examples/collect_evidence.py` | Synthetic example using bounded history, workouts and track context |
| `tests/test_protocol.py` | Synthetic schema, validation, projection, repair-prompt and scoring checks |
| `sources.json` | Source commits, line ranges, file hashes and exact prompt hashes |

## Run the checks

Requires Python 3.10 or later and the standard library. From this directory:

```sh
python3 -B check.py
```

The checks verify file hashes and run synthetic tests. A successful run ends in
`OK`. The combined supplement's top-level `check.py` also runs the existing
Code-as-policy component's tests.

## Sessions and inputs

Warmup explores legally released historical support and saves an evidence plan.
The updater receives released daily and cumulative summaries and the current
plan, then saves a validated candidate or retains the accepted plan. The saved
plan executes before each race and selects evidence through the restricted SDK.
A fresh LLM request receives the basic card, the SemanticJSON-Light evidence
package and ledger summary and submits the race forecast. A recoverable final
delivery error permits one repair request using the existing evidence.

The files `system.txt`, `warmup-system.txt`, `updater-system.txt` and
`repair-system.txt` preserve the historical model-visible text. Angle-bracketed
values in forecast and update context files document fields populated by the runtime. They
stand for typed objects or strings as indicated. The forecast tool enum and
ranking length are regenerated for each field of runners. `initial_context.json`
contains the bound warmup tariff and limits. The forecast request helper takes
an already projected observation and uses the source's exact compact UTF-8
JSON serializer, including rejection of non-finite values.

Warmup's read-tool schemas come from the same pinned v0.6.0 reference
specification bundled with Code-as-policy. The four construction tools come
from the audited acquisition builder. The individual forecast receives only
the native `submit` tool.

## Protocol and provenance

Prompt strings match six previously audited SHA-256 values. The original
source tree matches all 128 source pins for the published historical Frozen
tree. The R1 updater-fixed and Frozen deployments have distinct lifecycle
and supervisor bindings, documented in `sources.json`.

The prompt and updater Frame use the aligned delivery score. The final common
report grants the centered Top-1 term to every scored forecast, including
uniform delivery. Both views are explicit in `src/scoring.py` and its tests.
Research charges use score-yen. Provider dollars are a separate quantity.

These files provide an audited reference template. Exact request bodies and
wrapper settings for other model deployments are determined by their own
source and configuration bindings. Full trajectory execution remains in the
benchmark repository. Examples and test observations here are synthetic.

## License

Source excerpts retain the JockeyBench MIT license in `LICENSE`. Documentation,
packaging and synthetic tests were prepared with AI assistance.
