"""Native schemas and terminal-action parser extracted from the reference source."""
import json
from pathlib import Path
from .scoring import Rejected, validate

def native(name, description, props, required):
    return {"type":"function","function":{"name":name,"description":description,
        "parameters":{"type":"object","properties":props,"required":required,"additionalProperties":False}}}

def action_tools(numbers, submit_only=False):
    def tool(name, description, properties, required):
        return {"type": "function", "function": {"name": name, "description": description,
                "parameters": {"type": "object", "properties": properties,
                               "required": required, "additionalProperties": False}}}
    submit = tool("submit", "Seal final full ranking and probabilities for the current race.",
                  {"ranking": {"type": "array", "items": {"type": "string", "enum": numbers},
                               "minItems": len(numbers), "maxItems": len(numbers)},
                   "probabilities": {"type": "object", "properties": {
                       n: {"type": "number", "minimum": 0, "maximum": 1} for n in numbers},
                       "required": numbers, "additionalProperties": False}},
                  ["ranking", "probabilities"])
    if submit_only:
        return [submit]
    return [tool("form", "Paid pre-race recent historical form for this race's runners.",
                 {"k": {"type": "integer", "minimum": 1, "maximum": 5}}, ["k"]),
            tool("connections", "Paid as-of jockey/trainer counts for current runners.", {}, []),
            tool("card", "Paid full permitted current card, including training and other facts omitted from basic card.", {}, []),
            submit]

def parse_action(message, numbers, race, submit_only=False):
    calls = message.get("tool_calls") or []
    if len(calls) != 1:
        raise Rejected("Expected exactly one native action")
    call = calls[0]["function"]
    name = call["name"]
    try:
        args = json.loads(call["arguments"], parse_constant=lambda x: (_ for _ in ()).throw(ValueError()))
    except (ValueError, TypeError):
        raise Rejected("Action arguments must be finite JSON") from None
    if not isinstance(args, dict):
        raise Rejected("Action arguments must be an object")
    if name == "submit":
        if set(args) != {"ranking", "probabilities"}:
            raise Rejected("submit requires exactly ranking and probabilities")
        return {"type": "submit", "prediction": validate(args, numbers)}
    if submit_only:
        raise Rejected("Only submit is available")
    action = {"type": "query", "tool": name, "arguments": args}
    query_arguments(action, race)
    if name == "form" and set(args) != {"k"}:
        raise Rejected("form requires k")
    return action

def toolset():
    return [native('inspect_contract','Read the task, allowed SDK and interpreter contract.',{},[]),
        native('validate_research_policy','Run deterministic synthetic validation; no real race data.',{'source':{'type':'string'}},['source']),
        native('save_research_policy','Validate and save a candidate. Invalid candidate retains the previous valid program.',{'source':{'type':'string'}},['source']),
        native('finish','Finish construction or keep the current saved valid policy.',{},[])]

def serialize(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)

ROOT = Path(__file__).resolve().parents[1]

def submit_schema(numbers):
    return action_tools(numbers, submit_only=True)[0]

def parse_submit(message, numbers):
    return parse_action(message, numbers, "synthetic-race", submit_only=True)["prediction"]

def forecast_request(observation, numbers, repair=False):
    prompt_name = "repair-system.txt" if repair else "system.txt"
    return {"messages": [
        {"role": "system", "content": (ROOT / "prompts" / prompt_name).read_text(encoding="utf-8")},
        {"role": "user", "content": serialize(observation)}],
        "tools": [submit_schema(numbers)],
        "tool_choice": {"type": "function", "function": {"name": "submit"}},
        "parallel_tool_calls": False}
