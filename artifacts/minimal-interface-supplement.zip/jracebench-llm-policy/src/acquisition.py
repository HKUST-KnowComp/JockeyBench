"""Verbatim static acquisition validation and quality-only projection functions."""
import ast
import copy
import hashlib
from .scoring import Rejected

SUPPORTED = ("recent_history","training","condition_stats","track_context")

class PolicyInvalid(Rejected): pass

def source_hash(source): return hashlib.sha256(source.encode('utf-8')).hexdigest()

FORBIDDEN={'finish','winner','winners','win','wins','top3','rank','ranking','probability',
    'probabilities','prediction','predict','predicted','score','strength','payout','results',
    'backend','raw','run','service','source','globals','getattr','eval','exec','open',
    'network','model','submit','horse_id','earned_prize','class_prize'}

def forbidden(value):
    if value in {'raw_research_cost','weighted_research_cost'}:return False
    return any(x in FORBIDDEN for x in value.lower().replace('-','_').split('_'))

def parse_source(source):
    if not isinstance(source,str) or len(source.encode())>1024**2:raise PolicyInvalid('Source size')
    try:t=ast.parse(source)
    except (SyntaxError,RecursionError) as e:raise PolicyInvalid('Syntax') from e
    functions={}
    for f in t.body:
        if not isinstance(f,ast.FunctionDef) or f.name in functions:raise PolicyInvalid('Only unique functions')
        a=f.args
        if (f.decorator_list or f.returns or a.posonlyargs or a.kwonlyargs or a.defaults or
            a.kw_defaults or a.vararg or a.kwarg or any(x.annotation for x in a.args)):
            raise PolicyInvalid('Plain function signature only')
        if f.name.startswith('_') or forbidden(f.name):raise PolicyInvalid('Forbidden helper name')
        if f.name!='collect_evidence' and any(x.arg in {'sdk','context'} for x in a.args):raise PolicyInvalid('Helper capabilities forbidden')
        functions[f.name]=f
    if 'collect_evidence' not in functions or [x.arg for x in functions['collect_evidence'].args.args]!=['sdk','context']:
        raise PolicyInvalid('Required collect_evidence(sdk, context)')
    allowed=(ast.FunctionDef,ast.arguments,ast.arg,ast.Assign,ast.For,ast.If,ast.Return,
        ast.Expr,ast.Break,ast.Continue,ast.Pass,ast.Name,ast.Load,ast.Store,ast.Constant,
        ast.List,ast.Tuple,ast.Dict,ast.Subscript,ast.Call,ast.Attribute,ast.keyword,
        ast.Compare,ast.Eq,ast.NotEq,ast.Lt,ast.LtE,ast.Gt,ast.GtE,ast.In,ast.NotIn,
        ast.Is,ast.IsNot,ast.BoolOp,ast.And,ast.Or,ast.UnaryOp,ast.Not,ast.USub,ast.UAdd,
        ast.BinOp,ast.Add,ast.Sub,ast.Mult,ast.Div,ast.FloorDiv,ast.Mod)
    graph={k:set() for k in functions}
    for name,f in functions.items():
        for n in ast.walk(f):
            if not isinstance(n,allowed):raise PolicyInvalid('Unsupported syntax: '+type(n).__name__)
            if isinstance(n,ast.FunctionDef) and n is not f:raise PolicyInvalid('No nested functions')
            if isinstance(n,ast.Name) and (n.id.startswith('_') or forbidden(n.id)):raise PolicyInvalid('Forbidden identifier')
            if isinstance(n,ast.Constant) and isinstance(n.value,str) and forbidden(n.value):raise PolicyInvalid('Predictive/internal field forbidden')
            if isinstance(n,ast.Assign) and (len(n.targets)!=1 or not isinstance(n.targets[0],ast.Name)
                or n.targets[0].id in {'sdk','context'}|set(functions)):
                raise PolicyInvalid('Only local immutable bindings')
            if isinstance(n,ast.For) and (not isinstance(n.target,ast.Name) or n.target.id in {'sdk','context'}|set(functions)):
                raise PolicyInvalid('Local loop binding only')
            if isinstance(n,ast.Attribute) and n.attr not in {'call','state','package','stop_horse','stop_domain','get'}:
                raise PolicyInvalid('No object access')
            if isinstance(n,ast.Call):
                if isinstance(n.func,ast.Name):
                    if n.keywords or n.func.id not in {'len','range','sorted','min','max','abs'}|set(functions):raise PolicyInvalid('Unknown callable')
                    if n.func.id in functions:
                        graph[name].add(n.func.id)
                        if n.func.id=='collect_evidence':raise PolicyInvalid('No capability recursion')
                        if len(n.args)!=len(functions[n.func.id].args.args):raise PolicyInvalid('Helper arity')
                    if any(isinstance(x,ast.Name) and x.id=='sdk' for x in n.args):raise PolicyInvalid('No SDK escape')
                elif isinstance(n.func,ast.Attribute):
                    method=n.func.attr
                    if method=='get':
                        if n.keywords or not 1<=len(n.args)<=2:raise PolicyInvalid('get arity')
                    else:
                        if name!='collect_evidence' or not isinstance(n.func.value,ast.Name) or n.func.value.id!='sdk':raise PolicyInvalid('SDK root only')
                        if method=='call':
                            if len(n.args)!=1 or not isinstance(n.args[0],ast.Constant) or n.args[0].value not in SUPPORTED:raise PolicyInvalid('Four literal domains only')
                            domain=n.args[0].value; keys=[x.arg for x in n.keywords]
                            if set(keys)!=(set() if domain=='track_context' else {'horse_number'}) and not (domain=='recent_history' and set(keys)=={'horse_number','depth'}):raise PolicyInvalid('Query arguments')
                            if len(keys)!=len(set(keys)):raise PolicyInvalid('Duplicate arguments')
                            for k in n.keywords:
                                if k.arg=='depth' and isinstance(k.value,ast.Constant) and (type(k.value.value) is not int or k.value.value not in (1,3,5)):raise PolicyInvalid('Bounded history depth')
                        elif method in {'state','stop_horse'}:
                            if n.keywords or len(n.args) not in ((0,1) if method=='state' else (1,)):raise PolicyInvalid('SDK arity')
                        elif method=='stop_domain':
                            if n.keywords or len(n.args)!=2 or not isinstance(n.args[0],ast.Constant) or n.args[0].value not in SUPPORTED:raise PolicyInvalid('Stop domain')
                        elif n.args or n.keywords:raise PolicyInvalid('Package arguments')
                else:raise PolicyInvalid('No dynamic callable')
            if isinstance(n,ast.Return) and name=='collect_evidence' and not (
                isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and
                isinstance(n.value.func.value,ast.Name) and n.value.func.value.id=='sdk' and n.value.func.attr=='package'):
                raise PolicyInvalid('Return only trusted package')
    def visit(k,path):
        if k in path:raise PolicyInvalid('No recursive helper cycle')
        for v in graph[k]:visit(v,path|{k})
    for k in graph:visit(k,set())
    return functions

DEPTHS = (1, 3, 5)

DOMAIN_FIELDS = ('queried', 'query_count', 'queried_depth', 'records_returned',
    'missing_count', 'observed_slots', 'missing_ratio', 'feature_asof', 'freshness_days',
    'available_history_start_count', 'deeper_available', 'same_surface_records',
    'same_distance_records', 'sample_starts', 'labelled_starts', 'matching_groups')

def empty_domain():
    return dict(queried=False, query_count=0, queried_depth=0, records_returned=0,
        missing_count=0, observed_slots=0, missing_ratio=None, feature_asof=None,
        freshness_days=None, available_history_start_count=None, deeper_available=None,
        same_surface_records=0, same_distance_records=0, sample_starts=0,
        labelled_starts=0, matching_groups=0)

def quality(action, observation, native, card):
    """Value magnitudes/outcome labels never survive this fixed whitelist."""
    domain = action['domain']; result = empty_domain()
    result['queried'] = True
    if domain == 'recent_history':
        rows = observation['starts']; depth = action.get('depth', 5)
        result.update(queried_depth=depth, records_returned=len(rows), sample_starts=len(rows),
            labelled_starts=sum(s.get('values') is not None for s in rows),
            deeper_available=bool(native.get('next_cursor')) if depth < 5 else False)
        # A short delivered page proves the bounded total. A full page only
        # establishes a lower bound; exact unseen availability is not free.
        if len(rows) < depth: result['available_history_start_count'] = len(rows)
        current = card['facts']
        result['same_surface_records'] = sum(current.get('surface') is not None and
            s['race_facts'].get('surface') == current['surface'] for s in rows)
        result['same_distance_records'] = sum(current.get('distance') is not None and
            s['race_facts'].get('distance') == current['distance'] for s in rows)
        if rows: result['freshness_days'] = card['day_index'] - max(s['day_index'] for s in rows)
        slots = [v for s in rows for bucket in ('race_facts', 'runner_facts', 'values')
                 for v in (s.get(bucket) or {}).values()]
    elif domain == 'training':
        slots = list(observation['training'].values())
        result.update(records_returned=1, feature_asof=observation['feature_asof'])
    elif domain == 'condition_stats':
        slots = []
        groups = observation['groups']; facts = card['facts']
        result.update(records_returned=len(groups), sample_starts=observation['sample_starts'],
            labelled_starts=observation['labelled_starts'],
            matching_groups=sum(g.get('surface') == facts.get('surface') and
                g.get('distance') == facts.get('distance') and facts.get('surface') is not None
                and facts.get('distance') is not None for g in groups),
            same_surface_records=sum(g['starts'] for g in groups if facts.get('surface') is not None
                and g.get('surface') == facts['surface']),
            same_distance_records=sum(g['starts'] for g in groups if facts.get('distance') is not None
                and g.get('distance') == facts['distance']))
    else:
        slots = list(observation['facts'].values())
        result.update(records_returned=1, feature_asof=observation['feature_asof'])
    result.update(observed_slots=len(slots), missing_count=sum(v is None for v in slots))
    result['missing_ratio'] = result['missing_count'] / len(slots) if slots else None
    return result

def context(card):
    # No basic-card horse facts, draws, weights, sex, prize or hidden identity.
    return {'race_id':card['race_id'], 'day_index':card['day_index'],
        'feature_asof':card['feature_asof'], 'field_size':len(card['runners']),
        'runners':[{'number':r['number']} for r in card['runners']]}

def information_state(card, entries, events, stops=()):
    numbers = [r['number'] for r in card['runners']]
    state = {'field_size':len(numbers), 'query_count':len(events),
        'weighted_research_cost':sum(e['cost']['total_micro'] for e in events)/1e6,
        'raw_research_cost':sum(e['cost']['total_micro'] for e in events)/500000,
        'domains':{d:empty_domain() for d in SUPPORTED},
        'runners':{n:{'number':n,'stopped':n in stops,
                      'domains':{d:empty_domain() for d in SUPPORTED}} for n in numbers}}
    for action, obs, native in entries:
        d = action['domain']; n = action.get('horse_number')
        bucket = state['runners'][n]['domains'] if n else state['domains']
        old_count = bucket[d]['query_count']; bucket[d] = quality(action,obs,native,card)
        bucket[d]['query_count'] = old_count+1
    for d in SUPPORTED:
        if d == 'track_context': continue
        buckets = [state['runners'][n]['domains'][d] for n in numbers]
        state['domains'][d].update(queried=any(x['queried'] for x in buckets),
            query_count=sum(x['query_count'] for x in buckets),
            records_returned=sum(x['records_returned'] for x in buckets))
    state['domain_coverage'] = {d:sum(state['runners'][n]['domains'][d]['queried']
        for n in numbers)/len(numbers) if d!='track_context' else int(state['domains'][d]['queried'])
        for d in SUPPORTED}
    return copy.deepcopy(state)
