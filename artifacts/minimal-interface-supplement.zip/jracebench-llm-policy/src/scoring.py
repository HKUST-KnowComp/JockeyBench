"""Prediction validation and score components from the v0.6.0 evaluator."""
import math
import re

# Source: legacy/v060/jrdb_lh/common.py:11-12
class Rejected(RuntimeError):
    """Safe, public protocol error. Never include host paths or raw source values."""

# Source: legacy/v060/jrdb_lh/common.py:61-73
def number(value):
    if isinstance(value, bool):
        return None
    if isinstance(value, str):
        value = value.strip().translate(str.maketrans({'＋': '+', '－': '-'}))
        value = re.sub(r'^([+-])\s+(?=\d)', r'\1', value)
    try:
        n = float(value)
        if not (-1e12 < n < 1e12):
            return None
        return int(n) if n.is_integer() else n
    except (ValueError, TypeError, OverflowError):
        return None

# Source: legacy/v060/jrdb_lh/scoring.py:6-24
def validate_prediction(prediction, entrants):
    if not isinstance(prediction, dict) or set(prediction) - {'ranking', 'probabilities'}:
        raise Rejected('Prediction requires ranking and optional probabilities')
    ranking = prediction.get('ranking')
    if not isinstance(ranking, list) or any(type(n) is not str for n in ranking):
        raise Rejected('Ranking must contain runner number strings')
    if len(ranking) != len(entrants) or set(ranking) != set(entrants):
        raise Rejected('Ranking must contain each entrant exactly once; expected: ' + ', '.join(sorted(entrants)))
    probs = prediction.get('probabilities')
    if probs is not None:
        if not isinstance(probs, dict) or set(probs) != set(entrants):
            raise Rejected('Probabilities must cover all entrants')
        if any(type(v) not in (int, float) or not math.isfinite(v) or v < 0 or v > 1 for v in probs.values()):
            raise Rejected('Invalid probability')
        total = sum(probs.values())
        if total <= 0 or not math.isclose(total, 1, abs_tol=.02, rel_tol=0):
            raise Rejected('Probabilities must sum to one within 0.02 rounding tolerance')
        return {**prediction, 'probabilities': dict(probs) if abs(total - 1) < 1e-12 else {n: v / total for n, v in probs.items()}}
    return {**prediction}

# Source: legacy/v060/jrdb_lh/economic_scoring.py:13-17
def validate(prediction, entrants):
    prediction = validate_prediction(prediction, entrants)
    if not isinstance(prediction.get('probabilities'), dict):
        raise Rejected('Economic protocol requires probabilities for every entrant')
    return prediction

# Source: legacy/v060/jrdb_lh/economic_scoring.py:24-25
def hit_revenue(n, top1, bonus, delivery):
    return bonus * (int(top1) - 1 / n) if delivery == 'predictor' and bonus else 0.0

# Source: legacy/v060/jrdb_lh/economic_scoring.py:34-47
def sealed_revenue(prediction, fact, tariff, delivery):
    """Recompute both parts from sealed choices and booked outcome identities."""
    active = [i for i in prediction['ranking'] if i not in fact['scratches']]
    winners = fact['winners']
    if (active != fact['active'] or not active or not winners
            or len(set(winners)) != len(winners) or not set(winners) <= set(active)):
        raise Rejected('Invalid booked scoring outcome')
    n = len(active)
    mass = sum(prediction['probabilities'][i] for i in active)
    p = {i: prediction['probabilities'][i] / mass if mass else 1 / n for i in active}
    log = tariff.score_scale * math.log(n * sum(
        (1 - tariff.smoothing) * p[i] + tariff.smoothing / n for i in winners) / len(winners))
    return {'revenue_log_yen': log,
            'revenue_hit_yen': hit_revenue(n, active[0] in winners, tariff.hit_bonus_yen, delivery)}
# Publication adapter around the verbatim v0.6.0 primitives above.
# The two reporting views follow common_scoring.py and aligned/scoring.py.
from dataclasses import dataclass

@dataclass(frozen=True)
class Tariff:
    score_scale: float = 100.0
    smoothing: float = 0.02
    hit_bonus_yen: float = 0.0

DELIVERIES = ("direct_predictor", "repaired_predictor", "uniform_submit", "execution_fallback")

def score(prediction, fact, delivery="direct_predictor", raw_research_cost=0.0, view="common"):
    if delivery not in DELIVERIES or view not in ("common", "aligned"):
        raise Rejected("Unknown delivery or score view")
    if type(raw_research_cost) not in (int, float) or not math.isfinite(raw_research_cost) or raw_research_cost < 0:
        raise Rejected("Invalid research cost")
    prediction = validate(prediction, list(prediction["ranking"]))
    uniform = len(set(prediction["probabilities"].values())) == 1
    if (delivery in ("uniform_submit", "execution_fallback")) != uniform:
        raise Rejected("Delivery and uniformity differ")
    log_reward = sealed_revenue(prediction, fact, Tariff(), delivery)["revenue_log_yen"]
    n = len(fact["active"])
    bonus = 100.0 * (int(fact["active"][0] in fact["winners"]) - 1.0 / n)
    if view == "aligned" and delivery in ("uniform_submit", "execution_fallback"):
        bonus = 0.0
    gross = log_reward + bonus
    return {"view": view, "log_reward": log_reward, "hit_contribution": bonus,
            "gross": gross, "weighted_research_cost": 0.5 * raw_research_cost,
            "net": gross - 0.5 * raw_research_cost}
