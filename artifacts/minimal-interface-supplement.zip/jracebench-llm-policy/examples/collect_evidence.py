def collect_evidence(sdk, context):
    for runner in context["runners"]:
        number = runner["number"]
        sdk.call("recent_history", horse_number=number, depth=1)
        sdk.call("training", horse_number=number)
    sdk.call("track_context")
    return sdk.package()
