"""Check all packaged files and test the two components independently."""
import hashlib
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
for directory in (root, root / "jracebench-program", root / "jracebench-llm-policy"):
    expected = {}
    for line in (directory / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        path = directory / name
        assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(directory), name
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, name
        expected[name] = digest
    actual = {path.relative_to(directory).as_posix() for path in directory.rglob("*")
              if path.is_file() and (path != directory / "SHA256SUMS")}
    assert set(expected) == actual, str(directory)
for component in ("jracebench-program", "jracebench-llm-policy"):
    subprocess.run([sys.executable, "-B", "-m", "unittest", "discover", "-s", "tests", "-v"],
                   cwd=root / component, check=True)
print("Both reference components passed.")
