# JockeyBench minimal interface supplement

The supplement contains two independent reference components.

| Directory | Workflow |
| --- | --- |
| `jracebench-program/` | Code-as-policy, using the original supplied Program reference supplement |
| `jracebench-llm-policy/` | LLM-as-policy, with initial evidence-plan construction, daily updating, forecasting and repair |

The Program component is preserved byte for byte from the paper's supplied
supplement. Each component documents its source binding and tests. The
LLM-as-policy component uses the audited historical DeepSeek R1/Frozen
reference deployment.

Run both components' checksum and synthetic test checks from this directory:

```sh
python3 -B check.py
```

The benchmark repository is https://github.com/HKUST-KnowComp/JockeyBench.
