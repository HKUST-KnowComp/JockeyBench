def predict(sdk, context):
    card = sdk.call('card', race_id=context['race_id'])
    numbers = [runner['number'] for runner in card['runners']]
    return {'ranking': numbers, 'probabilities': {n: 1 / len(numbers) for n in numbers}}
