"""Tests of the Program interface and scoring rules on synthetic examples."""
import math
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
sys.path.insert(0, str(ROOT / 'examples'))
from scoring import Rejected, sealed_revenue, validate, validate_prediction
from uniform import predict

TARIFF = SimpleNamespace(score_scale=100, smoothing=.02, hit_bonus_yen=100)

def score(probabilities, ranking, winners, scratches=(), delivery='predictor'):
    prediction = validate({'ranking': ranking, 'probabilities': probabilities}, ranking)
    active = [n for n in ranking if n not in scratches]
    return sealed_revenue(prediction, {'active': active, 'winners': winners, 'scratches': list(scratches)}, TARIFF, delivery)

class SyntheticChecks(unittest.TestCase):
    def test_sdk_example_calls_supported_interface(self):
        class FakeSDK:
            def call(self, name, **kwargs):
                self.last_call = (name, kwargs)
                return {'runners': [{'number': '01'}, {'number': '02'}]}
        sdk = FakeSDK()
        prediction = predict(sdk, {'race_id': 'synthetic-example', 'seed': 0, 'runner_numbers': ['01', '02']})
        self.assertEqual(sdk.last_call, ('card', {'race_id': 'synthetic-example'}))
        self.assertEqual(validate_prediction(prediction, ['01', '02']), prediction)

    def test_uniform_log_and_ineligible_bonus_are_zero(self):
        result = score({'01': .5, '02': .5}, ['01', '02'], ['01'], delivery='silent_uniform')
        self.assertEqual(result, {'revenue_log_yen': 0, 'revenue_hit_yen': 0})

    def test_hit_bonus_and_log_have_separate_sources(self):
        result = score({'01': .75, '02': .25}, ['01', '02'], ['01'])
        self.assertAlmostEqual(result['revenue_log_yen'], 100 * math.log(1.49))
        self.assertEqual(result['revenue_hit_yen'], 50)

    def test_rank_need_not_be_probability_argmax(self):
        result = score({'01': .75, '02': .25}, ['02', '01'], ['01'])
        self.assertAlmostEqual(result['revenue_log_yen'], 100 * math.log(1.49))
        self.assertEqual(result['revenue_hit_yen'], -50)

    def test_execution_fallback_receives_no_bonus(self):
        result = score({'01': .75, '02': .25}, ['01', '02'], ['01'], delivery='execution_fallback')
        self.assertGreater(result['revenue_log_yen'], 0)
        self.assertEqual(result['revenue_hit_yen'], 0)

    def test_dead_heat_uses_log_of_mean_winner_probability(self):
        result = score({'01': .6, '02': .3, '03': .1}, ['01', '02', '03'], ['01', '02'])
        self.assertAlmostEqual(result['revenue_log_yen'], 100 * math.log(3 * (.98 * .45 + .02 / 3)))

    def test_zero_surviving_mass_becomes_uniform(self):
        result = score({'01': 1., '02': 0., '03': 0.}, ['01', '02', '03'], ['02'], scratches=['01'])
        self.assertEqual(result['revenue_log_yen'], 0)
        self.assertEqual(result['revenue_hit_yen'], 50)

    def test_small_rounding_error_is_normalized(self):
        value = validate_prediction({'ranking': ['01', '02'], 'probabilities': {'01': .51, '02': .5}}, ['01', '02'])
        self.assertAlmostEqual(sum(value['probabilities'].values()), 1)

    def test_duplicate_ranking_is_rejected(self):
        with self.assertRaises(Rejected):
            validate_prediction({'ranking': ['01', '01'], 'probabilities': {'01': .5, '02': .5}}, ['01', '02'])

    def test_nonfinite_probability_is_rejected(self):
        with self.assertRaises(Rejected):
            validate_prediction({'ranking': ['01', '02'], 'probabilities': {'01': float('nan'), '02': .5}}, ['01', '02'])

    def test_economic_protocol_requires_probabilities(self):
        with self.assertRaises(Rejected):
            validate({'ranking': ['01', '02']}, ['01', '02'])

    def test_nonzero_surviving_mass_is_renormalized(self):
        result = score({'01': .5, '02': .3, '03': .2}, ['01', '02', '03'], ['02'], scratches=['01'])
        self.assertAlmostEqual(result['revenue_log_yen'], 100 * math.log(2 * (.98 * .6 + .02 / 2)))
        self.assertAlmostEqual(result['revenue_hit_yen'], 50.)

    def test_probability_sum_outside_tolerance_is_rejected(self):
        with self.assertRaises(Rejected):
            validate({'ranking': ['01', '02'], 'probabilities': {'01': .53, '02': .5}}, ['01', '02'])

    def test_boolean_probability_is_rejected(self):
        with self.assertRaises(Rejected):
            validate({'ranking': ['01', '02'], 'probabilities': {'01': True, '02': False}}, ['01', '02'])

    def test_invalid_winner_is_rejected(self):
        with self.assertRaises(Rejected):
            score({'01': .5, '02': .5}, ['01', '02'], ['03'])

if __name__ == '__main__':
    unittest.main()
