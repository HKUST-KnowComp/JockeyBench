# JRaceBench: Program interface supplement

Prompts, implementation excerpts, and tests for the Program workflow described
in Appendices C and E of the paper.

## Files

| Path | Contents |
| --- | --- |
| `prompts/` | System prompt, tool schemas, phase instructions, and a synthetic initial task |
| `config/` | Reference configuration and environment metadata |
| `src/scoring.py` | Prediction validation, log score, and hit bonus |
| `examples/uniform.py` | Uniform forecast example from the SDK documentation |
| `reference/` | Session, validation, repair, fallback, and frozen-control excerpts |
| `tests/test_protocol.py` | Synthetic interface and scoring tests |
| `sources.json` | Source locations, versions, and hashes |

## Run the tests

Requires Python 3.10 or later and no additional packages. From this directory:

```sh
python3 -B check.py
```

The command checks file hashes and runs 15 tests. A successful run ends with
`OK`. Tests cover probability validation, scratches, dead heats, ranking, and
hit-bonus eligibility. All examples are synthetic; no database or model access
is needed.

## Source and scope

Implementation excerpts come from v0.6.0 (`economic-v1`, `objective-v5`,
`score-yen-v2`). Scoring function bodies and phase instructions are unchanged.
Files in `reference/` are source excerpts for inspection.

The system prompt matches a fresh render from the frozen core. Tool schemas,
initial context, and environment metadata come from the stored reference
specification. This template describes 324 races over 10 days; it does not
verify every historical client or run, and its configuration is not a race
manifest. Adaptive Acquisition is not included.

JRDB records, private identifier mappings, checkpoints, and model conversations
are not included. The tests check selected protocol rules; they do not reproduce
the paper's experimental results. The uniform example is neither a trained
predictor nor the seeded R0 implementation.

AI assistance was used for documentation, packaging, and synthetic tests.
